package com.tnsif.basics;

public class CharDemo {

	public static void main(String[] args) {
		// assigning single character literal
		char ch = 'a';
		StringBuffer name=new StringBuffer();
		System.out.println(ch);

		// assigning number to char
		char ch1 = 65;
		System.out.println(ch1);
		
		// assigning unicode to char
				char var1 = '\u0041';
				System.out.println(var1);
				
				// ASCI code representation

}
}
